package com.cybage.service;

public interface IProductService {
}
