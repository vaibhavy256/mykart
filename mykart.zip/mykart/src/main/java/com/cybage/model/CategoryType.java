package com.cybage.model;

public enum CategoryType {

    ELECTRONICS,FASHION,HOUSEHOLD,BOOKS,BEAUTY_PRODUCTS

}
