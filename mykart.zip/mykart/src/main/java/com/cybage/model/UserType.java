package com.cybage.model;

public enum UserType {
    CUSTOMER, SELLER, ADMIN
}
