package com.cybage.mykart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MykartApplicationTests {

	@Test
	void contextLoads() {
	}

}
